
      $(".nav1").children("li").click(function(){
			
//			console.log($(".div"+($(this).index()+1)).position())
			
//			拿到索引,计算选择器的数字
			var index = $(this).index()+1;
			
//			根据选择器选择到标签,获取距离顶部的位置
			var t = $(".floor"+index).offset().top;
			
//			设置动画
			$("html").animate({
				scrollTop:t
			})
			
		})























